//Creates the planets

//List of Planets
//PlanetsList = {};



//Forms the Sun
formSun = function() {
//PlanetsList.formSun = function() {

	//Creates Sphere Geometry
	var sunGeo = new THREE.SphereGeometry(0.5, 32, 32);

	//Creates Texture
	var sunTexture = THREE.ImageUtils.loadTexture('sunmap.jpg');

	//Creates MeshPhongMaterial
	var sunMat = new THREE.MeshPhongMaterial({
		sunMap: sunTexture,
		bumpMap: sunTexture,
		bumpScale: 0.05,
	});

	//Creates the mesh and adds in the Sphere Geometry and the Material
	var sunMesh = new THREE.Mesh(sunGeo, sunMat);
	return sunMesh;
}


//Forms Mercury
formMercury = function() {
	var mercuryGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var mercuryTexture = THREE.ImageUtils.loadTexture('images/mercurymap.jpg');

	var mercuryMat = new THREE.MeshPhongMaterial({
		mercuryMap: mercuryTexture,
		bumpMap: mercuryTexture,
		bumpScale: 0.05,
	});

	var mercuryMesh = new THREE.Mesh(mercuryGeo, mercuryMat);
	return mercuryMesh;
}


//Forms Venus
formVenus = function() {
	var venusGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var venusTexture = THREE.ImageUtils.loadTexture('images/venusmap.jpg');

	var venusMat = new THREE.MeshPhongMaterial({
		venusMap: venusTexture,
		bumpMap: venusTexture,
		bumpScale: 0.05,
	});

	var venusMesh = new THREE.Mesh(venusGeo, venusMat);
	return venusMesh;
}


//Forms Earth
formEarth = function() {
	var earthGeo = new THREE.SphereGeometry(0.5, 32, 32);

	//We put the texture in the material
	var earthMat = new THREE.MeshPhongMaterial({
		earthMap: THREE.ImageUtils.loadTexture('images/earthmap1k.jpg'),
		bumpMap: THREE.ImageUtils.loadTexture('images/earthbump1k.jpg'),
		bumpScale: 0.05,
	});

	var earthMesh = new THREE.Mesh(earthGeo, earthMat);
	return earthMesh;
}


//Forms Mars
formMars = function() {
	var marsGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var marsTexture = THREE.ImageUtils.loadTexture('images/marsmap1k.jpg');

	var marsMat = new THREE.MeshPhongMaterial({
		marsMap: marsTexture,
		bumpMap: marsTexture,
		bumpScale: 0.05,

	});

	var marsMesh = new THREE.Mesh(marsGeo, marsMat);
	return marsMesh;
}


//Forms Jupiter
formJupiter = function() {
	var jupiterGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var jupiterTexture = THREE.ImageUtils.loadTexture('images/jupitermap.jpg');

	var jupiterMat = new THREE.MeshPhongMaterial({
		jupiterMap: jupiterTexture,
		bumpMap: jupiterTexture,
		bumpScale: 0.05,
	});

	var jupiterMesh = new THREE.Mesh(jupiterGeo, jupiterMat);
	return jupiterMesh;
}


//Forms Saturn
formSaturn = function() {
	var saturnGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var saturnTexture = THREE.ImageUtils.loadTexture('images/saturnmap.jpg');

	var saturnMat = new THREE.MeshPhongMaterial({
		saturnMap: saturnTexture,
		bumpMap: saturnTexture,
		bumpScale: 0.05,
	});

	var saturnMesh = new THREE.Mesh(saturnGeo, saturnMat);
	return saturnMesh;
}


//Forms Uranus
formUranus = function() {
	var uranusGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var uranusTexture = THREE.ImageUtils.loadTexture('images/uranusmap.jpg');

	var uranusMat = new THREE.MeshPhongMaterial({
		uranusMap: uranusTexture,
		bumpMap: uranusTexture,
		bumpScale: 0.05,
	});

	uranusMesh = new THREE.Mesh(uranusGeo, uranusMat);
	return uranusMesh;
}


//Forms Neptune
formNeptune = function() {
	var neptuneGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var neptuneTexture = THREE.ImageUtils.loadTexture('images/neptunemap.jpg');

	var neptuneMat = new THREE.MeshPhongMaterial({
		neptuneMap: neptuneTexture,
		bumpMap: neptuneTexture,
		bumpScale: 0.05,
	});

	var neptuneMesh = new THREE.Mesh(neptuneGeo, neptuneMat);
	return neptuneMesh;
}


//Forms Pluto
formPluto = function() {
	var plutoGeo = new THREE.SphereGeometry(0.5, 32, 32);

	var plutoTexture = THREE.ImageUtils.loadTexture('images/plutomap1k.jpg');

	var plutoMat = new THREE.MeshPhongMaterial({
		plutoMap: plutoTexture,
		bumpMap: plutoTexture,
		bumpScale: 0.05,
	});

	var plutoMesh = new THREE.Mesh(plutoGeo, plutoMat);
	return plutoMesh;
}


//Forms the background galaxy of stars
formTheGalaxy = function() {
//PlanetsList.formTheGalaxy = function() {
	var galaxyTexture = THREE.ImageUtils.loadTexture('images/galaxy_starfield.png');

	var galaxyMat = new THREE.MeshBasicMaterial({
		galaxyMap: galaxyTexture,
		side: THREE.BackSide
	});

	var galaxyGeo = new THREE.SphereGeometry(100, 32, 32);

	var galaxyMesh = new THREE.Mesh(galaxyGeo, galaxyMat);
	return galaxyMesh;
}
